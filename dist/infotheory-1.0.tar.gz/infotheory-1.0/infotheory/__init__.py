from infotheory.infotools import InfoTools
from infotheory.infotools import __version__
